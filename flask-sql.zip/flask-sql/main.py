from flask import Flask, redirect, url_for, request, render_template
from flask_sqlalchemy import SQLAlchemy
from markupsafe import escape

app=Flask(__name__, static_folder='static', template_folder='templates')

db = SQLAlchemy()
# database config
# app.config['SQLALCHEMY_DATABASE_URI'] = "mysql+<driver>://user_name:password@IP:3306/db_name"
app.config['SQLALCHEMY_DATABASE_URI'] = "mysql+pymysql://root@localhost:3306/test"
db.init_app(app)

# model config
class Timetable(db.Model):
   __tablename__ = 'medic_data'
   user = db.Column(db.String(30), primary_key=True)
   light = db.Column(db.DateTime, nullable=True)
   noon = db.Column(db.DateTime, nullable=True)
   after = db.Column(db.DateTime, nullable=True)
   night = db.Column(db.DateTime, nullable=True)

   # init
   def __init__(self, user, light, noon, after, night):
      self.user = user
      self.light = light
      self.noon = noon
      self.after = after
      self.night = night


@app.route("/")
def form():
   return render_template('form.html')

@app.route("/submit", methods=['POST'])
def submit():
   user = 'test'
   light_time = request.values['light']
   noon_time = request.values['noon']
   after_time = request.values['after']
   night_time = request.values['night']
   db_data=Timetable(user, light_time, noon_time, after_time, night_time)
   # db.session.add(db_data) #add new data

   # datatime update
   targetData = Timetable.query.filter_by(user='test').first()
   if targetData.user is not None:
      targetData.light = light_time
      targetData.noon = noon_time
      targetData.after = after_time
      targetData.night = night_time
   else:
    # 處理物件為 None 的情況
      return "can't find data"

   db.session.commit()

   return render_template('submit.html',**locals())

@app.route("/<username>/light")
def lightTime(username):
   targetData = Timetable.query.filter_by(user=username).first()
   if targetData.user is not None:
      return str(targetData.light)
   else:
    # 處理物件為 None 的情況
      return "can't find data"

# db.create_all() //init create

if __name__ == '__main__':
   app.run(debug = True)